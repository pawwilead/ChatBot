import { conversation } from "~/model/models";

const conversations: { [key: string]: conversation } = {};

